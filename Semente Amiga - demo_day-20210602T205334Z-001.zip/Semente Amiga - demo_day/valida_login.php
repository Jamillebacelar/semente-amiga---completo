<?php 
//método é post - $_POST
$email=$_POST['email'];   //silvia@gmail.com   077.888.098-09
$senha=$_POST['senha'];  //123

//conexão
include('conexao.php');

//leitura
$sql="SELECT * FROM tbl_cadastro WHERE Email='$email' AND Senha='$senha'";


//executar
$resultado=mysqli_query($conn,$sql);
$linha=mysqli_fetch_array($resultado);


//fechando a conexão
mysqli_close($conn);

if ($linha) {      
    //variáveis de sessão
    //startar
    session_start();

    //variável superglobal $_SESSION
    $_SESSION['nome']=$linha['Nome'];
    $_SESSION['email']=$linha['Email'];

    echo ("<script>
        alert('Login efetuado com sucesso!');
        window.location.href='home.html';
    </script>");
}

else {
    
    echo("<script>
        alert('Usuário NÃO encontrado, cadastre-se!');
        window.location.href='cadastro.html';
    </script>");

}


?>