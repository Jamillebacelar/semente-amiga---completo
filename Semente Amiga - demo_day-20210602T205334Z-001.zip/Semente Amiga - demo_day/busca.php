<?php
include("conexao.php");
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="POST" action="">
        <input type="text" name="pesquisa">
        <input type="submit" name="btn-pesquisa" value="Pesquisar">
    </form>
<?php
$btnpesquisa = filter_input(INPUT_POST, 'btn-pesquisa', FILTER_SANITIZE_STRING);
if($btnpesquisa){
    $pesquisa = $_POST['pesquisa'];
    
    $result = "SELECT * FROM tbl_pesquisa WHERE pesquisa LIKE '%$pesquisa%'";

    $resultado_pesquisa = mysqli_query($conn, $result);
    
    while($row = mysqli_fetch_assoc($resultado_pesquisa)) {
        echo "ID: " . $row['id_planta'] . "<br>";
        echo "NOME: " . $row['pesquisa'] . "<br>";
        echo "FOTO: " . "<img src='imgpesquisa/" . $row['foto'] . "'> <br>";
        echo "DESCRIÇÃO: " . $row['descricao'] . "<br>";
    }
}
?>
</body>
</html>


