<?php

$nome=$_POST['nome'];
$sobrenome=$_POST['sobrenome'];
$email=$_POST['email'];
$senha=$_POST['senha'];



$link = mysqli_connect("localhost", "root", "root", "db_sementeamiga");

if(!$link){
die ('conexão falhou: ' . mysqli_connect_error());
}

else {
mysqli_query($link, "SET NAMES'utf8'");
mysqli_query($link, 'SET caracter_set_connection=utf8');
mysqli_query($link, 'SET caracter_set_client=utf8');
mysqli_query($link, 'SET caracter_set_results=utf8');
echo("<script>
        alert('Faça seu login!');
        window.location.href='login.html';
    </script>");

}

{
$sql = "INSERT INTO tbl_cadastro (Nome, Sobrenome, Email, Senha) 
VALUES ('$nome','$sobrenome','$email','$senha')";


$resultado=mysqli_query($link, $sql) or die ("Erro") ;
mysqli_close($link);
}
?>





