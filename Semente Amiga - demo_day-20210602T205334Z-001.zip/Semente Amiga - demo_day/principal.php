<?php
    session_start();

    echo ('<br>Email: '.$_SESSION['email']);


?>