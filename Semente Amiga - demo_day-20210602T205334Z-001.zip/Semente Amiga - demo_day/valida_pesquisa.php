<?php
//método é post - $_POST
$pesquisa=$_POST["pesquisa"];
$foto=$_POST["foto"];   //silvia@gmail.com   077.888.098-09
$descricao=$_POST["descricao"];

$link = mysqli_connect("localhost", "root", "root", "db_sementeamiga");

if(!$link){
die ('conexão falhou: ' . mysqli_connect_error());
}

else {
mysqli_query($link, "SET NAMES'utf8'");
mysqli_query($link, 'SET caracter_set_connection=utf8');
mysqli_query($link, 'SET caracter_set_client=utf8');
mysqli_query($link, 'SET caracter_set_results=utf8');
echo 'sucesso';

}

{
$sql = "INSERT INTO tbl_pesquisa (pesquisa, foto, descricao) 
VALUES ('$pesquisa','$foto','$descricao')";


$resultado=mysqli_query($link, $sql) or die ("erro") ;
echo ('<script>alert("registro feito"); </script>');

mysqli_close($link);
}
?>