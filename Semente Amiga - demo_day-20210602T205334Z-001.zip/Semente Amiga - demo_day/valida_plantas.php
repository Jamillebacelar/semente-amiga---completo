<?php

$email=$_POST['email'];   
$senha=$_POST['senha'];  


$foto=$_POST['foto'];
$desc_planta=$_POST['desc_planta'];



$link = mysqli_connect("localhost", "root", "root", "db_sementeamiga");

if(!$link){
die ('conexão falhou: ' . mysqli_connect_error());
}

else {
mysqli_query($link, "SET NAMES'utf8'");
mysqli_query($link, 'SET caracter_set_connection=utf8');
mysqli_query($link, 'SET caracter_set_client=utf8');
mysqli_query($link, 'SET caracter_set_results=utf8');
echo 'sucesso';

}

{
$sql = "INSERT INTO tbl_pesquisa (foto,desc_planta) 
VALUES ('$foto','$desc_planta')";


$resultado= mysqli_query($link, $sql) or die ("erro") ;
echo ('<script>alert("registro feito"); </script>');

mysqli_close($link);
}
?>

